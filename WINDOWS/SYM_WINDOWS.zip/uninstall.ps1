Write-Output 'Uninstalling Sensor on Windows...'
