#!/bin/bash

echo 'Uninstalling ExamplePackage on Amazon Linux...'

# Add command to call uninstaller.  For example "yum remove .\ExamplePackage.rpm"